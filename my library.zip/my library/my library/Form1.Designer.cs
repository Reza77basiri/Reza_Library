﻿namespace my_library
{
    partial class panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.books = new System.Windows.Forms.Button();
            this.parts = new System.Windows.Forms.Button();
            this.trust = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // books
            // 
            this.books.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.books.Location = new System.Drawing.Point(41, 83);
            this.books.Name = "books";
            this.books.Size = new System.Drawing.Size(404, 42);
            this.books.TabIndex = 0;
            this.books.Text = "کتاب ها";
            this.books.UseVisualStyleBackColor = false;
            this.books.Click += new System.EventHandler(this.books_Click);
            // 
            // parts
            // 
            this.parts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.parts.Location = new System.Drawing.Point(41, 131);
            this.parts.Name = "parts";
            this.parts.Size = new System.Drawing.Size(404, 42);
            this.parts.TabIndex = 1;
            this.parts.Text = "اعضاء";
            this.parts.UseVisualStyleBackColor = false;
            this.parts.Click += new System.EventHandler(this.parts_Click);
            // 
            // trust
            // 
            this.trust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.trust.Location = new System.Drawing.Point(41, 179);
            this.trust.Name = "trust";
            this.trust.Size = new System.Drawing.Size(404, 42);
            this.trust.TabIndex = 2;
            this.trust.Text = "امانت داری";
            this.trust.UseVisualStyleBackColor = false;
            this.trust.Click += new System.EventHandler(this.trust_Click);
            // 
            // help
            // 
            this.help.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.help.Location = new System.Drawing.Point(41, 227);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(404, 42);
            this.help.TabIndex = 4;
            this.help.Text = "راهنما";
            this.help.UseVisualStyleBackColor = false;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.exit.Location = new System.Drawing.Point(41, 275);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(404, 42);
            this.exit.TabIndex = 5;
            this.exit.Text = "خروج";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(501, 446);
            this.ControlBox = false;
            this.Controls.Add(this.exit);
            this.Controls.Add(this.help);
            this.Controls.Add(this.trust);
            this.Controls.Add(this.parts);
            this.Controls.Add(this.books);
            this.Name = "panel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "panel";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button books;
        private System.Windows.Forms.Button parts;
        private System.Windows.Forms.Button trust;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Button exit;
    }
}

