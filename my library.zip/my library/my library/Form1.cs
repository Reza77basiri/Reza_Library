﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 
namespace my_library
{
    public partial class panel : Form
                    
    {panel_books panelbooks = new panel_books();
        Member_panel memberpanel = new Member_panel();
        amant amant = new amant();
        public panel()
        {
            InitializeComponent();
        }

        private void books_Click(object sender, EventArgs e)
        {
            this.Hide();
            panelbooks.Show();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();panelbooks.Close();memberpanel.Close(); System.Environment.Exit(0);
        }

        private void parts_Click(object sender, EventArgs e)
        {
            this.Hide();
            memberpanel.Show();
        }

        private void help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("همچین راهنمایی خاصی لازم نداره ولی کلاس داره برنامه بخش راهنما داشته باشه");
        }

        private void trust_Click(object sender, EventArgs e)
        {
            amant.Show();
            this.Hide();
        }
    }
}
