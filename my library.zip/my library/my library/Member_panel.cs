﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace my_library
{
    public partial class Member_panel : Form
    {
        public void ReadFromDatabase()
        
        {
            //فروخوانی دیتا بیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //readdatabase
            mycom.CommandText = "select * from Table2";
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public void SearchDatabase()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from [Table2] where name like @name";
            mycom.Parameters.AddWithValue("@name", "%" + textBox1.Text + "%");
            mycom.CommandText = "select * from [Table2] where family like @family";
            mycom.Parameters.AddWithValue("@family", "%" + textBox1.Text + "%");
            mycom.CommandText = "select * from [Table2] where codeid like @codeid";
            mycom.Parameters.AddWithValue("@codeid", "%" + textBox1.Text + "%");
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public Member_panel()
        {
            InitializeComponent();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            panel a = new panel();
            
            this.Close();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var rez = MessageBox.Show("آیا مایل به حذف هستید؟", "هشدار", MessageBoxButtons.YesNo);
            if (rez == DialogResult.Yes)
            {
                //فروخوانی با دیتا بیس
                SqlConnection my = new SqlConnection();
                my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                SqlCommand mycom = new SqlCommand();
                mycom.Connection = my;
                //واردکردن به دیتا بیس
                my.Open();
                mycom.CommandText = "delete from Table2 where ID=@ID";
                mycom.Parameters.AddWithValue("@ID", dataGridView1.CurrentRow.Cells["clmid"].Value);
                mycom.ExecuteNonQuery();
                my.Close();
                ReadFromDatabase();
            }
        }
        private void Member_panel_Load(object sender, EventArgs e)
        {
            groupBox3.Hide();
            groupBox2.Hide();
            groupBox1.Hide();
            button3.Hide();
            button1.Hide();
        }

        private void btnlist_Click(object sender, EventArgs e)
        {
            groupBox3.Show();
            ReadFromDatabase();
            btnadd.Hide();btnkart.Hide();btnlist.Hide();button1.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            groupBox2.Show();
            btnadd.Hide(); btnkart.Hide(); btnlist.Hide();button1.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox2.Hide();
            groupBox3.Hide();
            btnkart.Show();
            btnadd.Show();
            btnlist.Show();
            button1.Hide();
            
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtfamily.Text == "")
            {
                MessageBox.Show("لطفا اطلاعات را به درستی وارد کنید");
            }
            else
            {
                //فروخوانی با دیتا بیس
                SqlConnection my = new SqlConnection();
                my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                SqlCommand mycom = new SqlCommand();
                mycom.Connection = my;
                //واردکردن به دیتا بیس
                my.Open();
                mycom.CommandText = "INSERT INTO Table2 (name,family,namepedar,codemeli,codeid)values('" + txtname.Text + "','" + txtfamily.Text + "','" + txtnamepedar.Text + "','" + txtcodemeli.Text + "','" + txtcodeid.Text + "')";
                mycom.ExecuteNonQuery();
                my.Close();
                //
                MessageBox.Show(txtname.Text + " " + "با موفقیقت ثبت شد ");
                txtname.Text = ""; txtfamily.Text = ""; txtnamepedar.Text = "";txtcodemeli.Text = ""; txtcodeid.Text = "";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("لطفا اطلاعات را به درستی وارد کنید");
            }
            else
            {

                var rez = MessageBox.Show("آیا مایل به ویرایش هستید؟", "هشدار", MessageBoxButtons.YesNo);
                if (rez == DialogResult.Yes)
                {
                    //فروخوانی با دیتا بیس
                    SqlConnection my = new SqlConnection();
                    my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                    SqlCommand mycom = new SqlCommand();
                    mycom.Connection = my;
                    //واردکردن به دیتا بیس
                    my.Open();
                    mycom.CommandText = "UPDATE table2 SET name=@name,family=@family,namepedar=@namepedar,codemeli=@codemeli,codeid=@codeid WHERE id=@id";
                    mycom.Parameters.AddWithValue("@ID", dataGridView1.CurrentRow.Cells["clmid"].Value);
                    mycom.Parameters.AddWithValue("@name", textBox6.Text);
                    mycom.Parameters.AddWithValue("@family", textBox5.Text);
                    mycom.Parameters.AddWithValue("@namepedar", textBox4.Text);
                    mycom.Parameters.AddWithValue("@codemeli", textBox3.Text);
                    mycom.Parameters.AddWithValue("@codeid", textBox2.Text);


                    mycom.ExecuteNonQuery();
                    my.Close();
                    ReadFromDatabase();
                    textBox2.Text = ""; textBox3.Text = ""; textBox4.Text = ""; textBox5.Text = ""; textBox6.Text = "";

                }

                else
                {
                    groupBox1.Hide();
                    textBox2.Text = ""; textBox3.Text = ""; textBox4.Text = ""; textBox5.Text = ""; textBox6.Text = "";
                }
            }
            }

        private void button7_Click(object sender, EventArgs e)
        {
            groupBox1.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty)

                SearchDatabase();
            button3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ReadFromDatabase();
            textBox1.Text = "";
            button3.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("جستجو فقط از طریق نام ، نام خانوادگی و کد کاربری صورت میگیرد");
        }

        private void btnkart_Click(object sender, EventArgs e)
        {
            btnadd.Hide(); btnkart.Hide(); btnlist.Hide();button1.Show();

        }
    }
}
