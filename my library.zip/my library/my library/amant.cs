﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace my_library
{
    public partial class amant : Form
    {

        public void ReadFromDatabase()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from Table3";
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public void SearchDatabase()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from [Table1] where codeb=@codeb";
            mycom.Parameters.AddWithValue("@codeb",textBox1.Text );
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView2.DataSource = mytab;
        }
        public void SearchDatabasee()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from [Table2]where codeid = @codeid";
            mycom.Parameters.AddWithValue("@codeid", textBox2.Text);

            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView3.DataSource = mytab;
        }
        public void SearchDatabaseee()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from [Table3] where namebook like @namebook";
            mycom.Parameters.AddWithValue("@namebook", "%" + textBox7.Text + "%");
            mycom.CommandText = "select * from [Table3] where code like @code";
            mycom.Parameters.AddWithValue("@code", "%" + textBox7.Text + "%");
            mycom.CommandText = "select * from [Table3] where nameuser like @nameuser";
            mycom.Parameters.AddWithValue("@nameuser", "%" + textBox7.Text + "%");
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public amant()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ReadFromDatabase();
            ReadFromDatabase();
            groupBox3.Show();
            button3.Hide();
            button6.Hide();
            button9.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                SearchDatabase();
                SearchDatabasee();
                button5.Show();
                dataGridView2.Show();
                dataGridView3.Show();
            }
            else
                MessageBox.Show("مشخصات را به درستی وارد کنید");


        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            groupBox2.Show();
            textBox4.Text = dataGridView2.CurrentRow.Cells["cmlnname"].Value.ToString();
            textBox5.Text = dataGridView2.CurrentRow.Cells["cmlncode"].Value.ToString();
            textBox3.Text = dataGridView3.CurrentRow.Cells["clmcodeid"].Value.ToString();


        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void amant_Load(object sender, EventArgs e)
        {
            groupBox1.Hide();
            groupBox2.Hide();
            button5.Hide();
            dataGridView2.Hide();
            dataGridView3.Hide();
            button9.Hide();
            groupBox3.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //فروخوانی با دیتا بیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //واردکردن به دیتا بیس
            my.Open();
            mycom.CommandText = "INSERT INTO Table3 (namebook,code,nameuser)values('" + textBox4.Text + "','" + textBox5.Text + "','" + textBox3.Text + "')";
            mycom.ExecuteNonQuery();
            my.Close();
            ReadFromDatabase();

            //

            dataGridView2.Hide();
            dataGridView3.Hide();
            button5.Hide();
            groupBox2.Hide();
            textBox1.Text = ""; textBox2.Text = ""; textBox4.Text = ""; textBox5.Text = ""; textBox3.Text = "";

        }

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
            button3.Hide();
            button6.Hide();
            button9.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel panel = new panel();
            panel.Show();
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            groupBox1.Hide();
            button3.Show();
            button6.Show();
            button9.Hide();
            groupBox3.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var rez = MessageBox.Show("آیا مایل به حذف هستید؟", "هشدار", MessageBoxButtons.YesNo);
            if (rez == DialogResult.Yes)
            {
                //فروخوانی با دیتا بیس
                SqlConnection my = new SqlConnection();
                my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                SqlCommand mycom = new SqlCommand();
                mycom.Connection = my;
                //واردکردن به دیتا بیس
                my.Open();
                mycom.CommandText = "delete from Table3 where ID=@ID";
                mycom.Parameters.AddWithValue("@ID", dataGridView1.CurrentRow.Cells["clmnid"].Value);
                mycom.ExecuteNonQuery();
                my.Close();
                ReadFromDatabase();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SearchDatabaseee();
            button4.Hide();

        }

        private void search_Click(object sender, EventArgs e)
        {
            button4.Show();
            textBox7.Text = "";
        }
    }
}
