﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace my_library
{
    public partial class panel_books : Form
    {
        
           
        public void ReadFromDatabase()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from Table1";
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public void SearchDatabase()
        {
            //فرواخوانی ئیتابیس
            SqlConnection my = new SqlConnection();
            my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
            SqlCommand mycom = new SqlCommand();
            mycom.Connection = my;
            //خاندن از دیتابیس
            mycom.CommandText = "select * from [Table1] where nameb like @nameb";
            mycom.Parameters.AddWithValue("@nameb","%"+ textBox1.Text+"%");
            DataTable mytab = new DataTable();
            SqlDataAdapter mydatad = new SqlDataAdapter();
            mydatad.SelectCommand = mycom;
            mydatad.Fill(mytab);
            dataGridView1.DataSource = mytab;
        }
        public panel_books()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
            panel panel = new panel();
            panel.Show();

        }




        private void panel_books_Load(object sender, EventArgs e)
        {
            groupBox1.Hide();
            groupBox3.Hide();
            groupBox2.Hide();
            ReadFromDatabase();
            button4.Hide();
            bak.Hide();
           
        }



        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtcode.Text == "")
            {
                MessageBox.Show("لطفا اطلاعات را به درستی وارد کنید");
            }
            else
            {
                //فروخوانی با دیتا بیس
                SqlConnection my = new SqlConnection();
                my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                SqlCommand mycom = new SqlCommand();
                mycom.Connection = my;
                //واردکردن به دیتا بیس
                my.Open();
                mycom.CommandText = "INSERT INTO Table1 (nameb,codeb)values('" + txtname.Text + "','" + txtcode.Text + "')";
                mycom.ExecuteNonQuery();
                my.Close();
                //
                MessageBox.Show(txtname.Text + " " + "با موفقیقت ثبت شد ");
                txtname.Text = ""; txtcode.Text = "";
            }
            

        }

        private void bak_Click(object sender, EventArgs e)
        {
            groupBox2.Hide();
            groupBox3.Hide();
            button1.Show();
            button3.Show();
            bak.Hide();
            groupBox1.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            bak.Show();
            groupBox3.Show();
            ReadFromDatabase();
            button1.Hide();
            button3.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bak.Show();
            groupBox2.Show();
            button3.Hide();
            button1.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            
                  
            var rez = MessageBox.Show("آیا مایل به حذف هستید؟","هشدار", MessageBoxButtons.YesNo);
                if (rez == DialogResult.Yes)
                {
                    //فروخوانی با دیتا بیس
                    SqlConnection my = new SqlConnection();
                    my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                    SqlCommand mycom = new SqlCommand();
                    mycom.Connection = my;
                    //واردکردن به دیتا بیس
                    my.Open();
                    mycom.CommandText = "delete from Table1 where ID=@ID";
                    mycom.Parameters.AddWithValue("@ID", dataGridView1.CurrentRow.Cells["clmnid"].Value);
                    mycom.ExecuteNonQuery();
                    my.Close();
                    ReadFromDatabase();
                
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty)
            
            SearchDatabase();
            button4.Show();
            
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReadFromDatabase();
            textBox1.Text = "";
            button4.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (nameup.Text == "" || codeup.Text == "")
            {
                MessageBox.Show("لطفا اطلاعات را به درستی وارد کنید");
            }
            else
            {
                var rez = MessageBox.Show("آیا مایل به ویرایش هستید؟", "هشدار", MessageBoxButtons.YesNo);
                if (rez == DialogResult.Yes)
                {
                    //فروخوانی با دیتا بیس
                    SqlConnection my = new SqlConnection();
                    my.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Usser\Documents\book.mdf;Integrated Security=True;Connect Timeout=30";
                    SqlCommand mycom = new SqlCommand();
                    mycom.Connection = my;
                    //واردکردن به دیتا بیس
                    my.Open();
                    mycom.CommandText = "UPDATE table1 SET nameb=@nameb,codeb=@codeb WHERE id=@id";
                    mycom.Parameters.AddWithValue("@ID", dataGridView1.CurrentRow.Cells["clmnid"].Value);
                    mycom.Parameters.AddWithValue("@nameb", nameup.Text);
                    mycom.Parameters.AddWithValue("@codeb", codeup.Text);
                    mycom.ExecuteNonQuery();
                    my.Close();
                    ReadFromDatabase();
                    nameup.Text = ""; codeup.Text = ""; groupBox1.Hide();
                }
                else
                {
                    groupBox1.Hide();
                    nameup.Text = ""; codeup.Text = "";
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            nameup.Text = ""; codeup.Text = ""; groupBox1.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("در این بخش میتوانید کتاب ها را با دکمه افزودن کتاب ثبت کرده و به لیست کتاب های ثبت شده با دکمه لیست کتاب ها دسترسی پیدا کنید ");
        }
    }
}
